1 case_example
This directory provides official test cases, you can use these cases to debug.
usage:
for c/c++   ./cdn        case_example/case0.txt  your_path/result.txt
for java   ./startup.sh  case_example/case0.txt  your_path/result.txt  
for details, plz look up the readme.txt in SDK-gcc.zip or SDK-java.zip.

2 SDK-gcc.zip
The c/c++ software development framework, you need to implement business logic based on this framework. For more information, see readme.txt in the file.

3 SDK-java.zip
The java software development framework, you need to implement business logic based on this framework. For more information, see readme.txt in the file.

4 FAQ.docx
Software contest-related FAQ

5 answer_demo
You can directly upload the answer demo.