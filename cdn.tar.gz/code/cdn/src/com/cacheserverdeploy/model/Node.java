package com.cacheserverdeploy.model;

/**
 * Created by kyle on 3/12/17.
 */
public class Node {
}
